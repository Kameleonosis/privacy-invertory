document.getElementById("open").addEventListener("click", () => {
chrome.runtime.openOptionsPage();
});